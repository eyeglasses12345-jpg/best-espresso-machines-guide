# Page Map

Each page should be produced as its own markdown file.

Recommended output folder structure:

```text
/pages/
  /batch-01-money-pages/
  /batch-02-budget-buyer-fit/
  /batch-03-machine-drink-intent/
  /batch-04-comparison-decision/
  /batch-05-regret-prevention/
  /batch-06-maintenance-ownership/
```

## Required Page Fields

Each page file should include:

```yaml
page_title:
seo_title:
slug:
meta_description:
batch:
category:
page_type:
primary_intent:
affiliate_intent:
primary_question:
target_reader:
recommended_products:
internal_links:
status:
```

## Page Types

Use these labels:

- money_page
- budget_page
- buyer_fit_page
- drink_intent_page
- machine_type_page
- comparison_page
- regret_prevention_page
- maintenance_page
- troubleshooting_page
- product_review_page

## Affiliate Intent Labels

Use these labels:

- high
- medium
- low
- support_only

## Status Labels

Use these labels:

- planned
- ready_for_codex
- generated
- reviewed
- revised
- published
