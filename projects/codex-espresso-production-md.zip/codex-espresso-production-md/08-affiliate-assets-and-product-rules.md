# Affiliate Assets and Product Rules

## Affiliate Site Principle

This site must be a true authority affiliate site, not a thin product list.

Every product must have a role.

Do not recommend products randomly.
Do not duplicate the same product across pages unless its role is clear.

## Product Role Examples

Use labels such as:

- Best overall
- Best for beginners
- Best under $500
- Best premium pick
- Best compact option
- Best for lattes
- Best with grinder
- Best automatic option
- Best semi-automatic option
- Best low-maintenance option
- Best for small kitchens
- Best for milk drinks
- Best value pick

## Affiliate CTA Rules

Every commercial product mention should eventually support an affiliate CTA.

Approved CTA language:
- Check current price on Amazon
- See today’s price on Amazon
- View on Amazon
- Compare current price

Avoid:
- Buy now
- Guaranteed best price
- Limited-time deal unless verified
- Overhyped claims

## Image Rules

Use approved Amazon image URLs where supplied.
Do not scrape or invent image URLs.

When product images are available, include a clear image placement note:

```html
<!-- VA NOTE: Insert approved Amazon product image here -->
```

## Known Approved Asset

Silonn approved pairing:

- Affiliate URL: https://amzn.to/49Fnsfx
- Image URL: https://m.media-amazon.com/images/I/71InTf6sgLL._AC_SL1500_.jpg

Use this exact pairing wherever Silonn appears unless a newer approved asset is provided.
