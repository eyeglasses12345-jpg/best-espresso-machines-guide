# Page Production Template

Each page Codex generates should follow this structure.

## Metadata Block

```yaml
page_title:
seo_title:
slug:
meta_description:
batch:
category:
page_type:
primary_intent:
affiliate_intent:
primary_question:
target_reader:
recommended_products:
internal_links:
```

## Snippet

One direct answer sentence at the top.

Requirements:
- directly answer the search question
- be concise
- be click/usefulness oriented
- no fluff
- no vague intro

## HTML Description

Start with the direct answer in bold.

Do not include an H1.
The CMS/WordPress title handles the H1.

Use HTML for the description body.

Required sections:
- direct answer
- who this page is for
- quick recommendation summary
- product/option breakdown
- decision criteria
- buyer mistakes or tradeoffs
- final recommendation
- internal links where relevant

## Product Tables

If a table is needed, do not use raw HTML table code unless specifically requested.

Use this VA note:

```html
<!-- VA NOTE: Insert a Gutenberg table block here using the data below -->
```

Then provide the table data in markdown.

## FAQ Section

Provide paste-ready HTML FAQ.

Use real buyer questions.
Do not add filler questions.

## Schema Section

Provide matching JSON-LD schema.

Use:
- Article or WebPage schema
- FAQPage schema when FAQ exists
- Product/ItemList schema only when supported by product data

## CTA Rules

Affiliate CTAs should be clear but not aggressive.

Good CTA examples:
- Check current price on Amazon
- See today’s price
- View on Amazon
- Compare current price

Avoid:
- Buy now!!!
- Best deal guaranteed
- Limited-time claim unless verified
