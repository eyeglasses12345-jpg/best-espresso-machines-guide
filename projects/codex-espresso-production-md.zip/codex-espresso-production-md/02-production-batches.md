# Production Batches

## Batch 1 — Core Money Pages

Goal:
Build the primary affiliate pages first.

Priority:
Highest.

Pages:
1. Best Espresso Machines
2. Best Espresso Machines for Beginners
3. Best Espresso Machines Under $500
4. Best Espresso Machines Under $1000
5. Best Espresso Machines for Lattes
6. Best Espresso Machines with Grinder
7. Best Automatic Espresso Machines
8. Best Semi-Automatic Espresso Machines
9. Best Compact Espresso Machines
10. Best Espresso Machines for Small Kitchens

Internal linking:
- Every page links to the main Best Espresso Machines page.
- Budget pages link to beginner and comparison pages.
- Drink pages link to milk drink and machine type pages.
- Compact/small kitchen pages link to beginner and budget pages.

---

## Batch 2 — Budget + Buyer Fit Pages

Goal:
Expand the site around buyer constraints.

Pages:
1. Best Espresso Machines Under $200
2. Best Espresso Machines Under $300
3. Cheap Espresso Machines Worth Buying
4. Are Expensive Espresso Machines Worth It?
5. Best Espresso Machine for Home Baristas
6. Best Espresso Machine for Apartment Kitchens
7. Best Espresso Machine for Busy Mornings
8. Best Espresso Machine for Coffee Lovers
9. Best Espresso Machine for People Who Hate Complicated Machines
10. How Much Should You Spend on an Espresso Machine?

Internal linking:
- Budget pages link upward to Under $500 and Under $1000 pages.
- Buyer-fit pages link to beginner, compact, automatic, and semi-automatic pages.
- The spending guide links to all budget tiers.

---

## Batch 3 — Machine Type + Drink Intent Pages

Goal:
Cover machine category searches and drink-specific intent.

Pages:
1. Best Super-Automatic Espresso Machines
2. Best Manual Espresso Machines
3. Best Capsule Espresso Machines
4. Best Espresso Machines for Cappuccinos
5. Best Espresso Machines for Americano
6. Best Espresso Machines for Iced Lattes
7. Best Espresso Machines for Milk Drinks
8. Best Espresso Machines for Straight Espresso
9. Best Espresso Machines with Milk Frother
10. Best Espresso Machines Without Grinder

Internal linking:
- Machine type pages link sideways to comparison pages.
- Drink pages link to milk frother, latte, cappuccino, and straight espresso pages.
- Super-automatic pages link to automatic vs semi-automatic comparison.

---

## Batch 4 — Comparison / Decision Pages

Goal:
Resolve buyer confusion and support money pages.

Pages:
1. Automatic vs Semi-Automatic Espresso Machine
2. Espresso Machine vs Nespresso
3. Espresso Machine vs Coffee Maker
4. Built-In Grinder vs Separate Grinder
5. Single Boiler vs Dual Boiler Espresso Machine
6. Thermoblock vs Boiler Espresso Machine
7. Breville Barista Express vs Bambino Plus
8. Breville Bambino vs Bambino Plus
9. DeLonghi vs Breville Espresso Machine
10. Super-Automatic vs Semi-Automatic Espresso Machine

Internal linking:
- Every comparison page links to the relevant money page.
- Product comparison pages link to full product review pages if/when created.
- Decision pages should include “who should choose each” sections.

---

## Batch 5 — Regret Prevention + Education Pages

Goal:
Build authority and answer pre-purchase doubts.

Pages:
1. What to Know Before Buying an Espresso Machine
2. Common Espresso Machine Buying Mistakes
3. Is a Home Espresso Machine Worth It?
4. Why Cheap Espresso Machines Disappoint Buyers
5. Do You Need a Grinder for Espresso?
6. What Pressure Is Best for Espresso?
7. Is 15 Bar Pressure Good for Espresso?
8. What Makes a Good Espresso Machine?
9. What Is the Best Espresso Machine for Home Use?
10. Should Beginners Buy an Automatic Espresso Machine?

Internal linking:
- Education pages link back to the most relevant money page.
- Mistake pages link to beginner, budget, and grinder pages.
- Pressure/grinder pages link to semi-automatic and built-in grinder pages.

---

## Batch 6 — Ownership / Maintenance Pages

Goal:
Complete topical authority and support long-tail traffic.

Pages:
1. How to Clean an Espresso Machine
2. How Often Should You Descale an Espresso Machine?
3. Espresso Machine Maintenance Guide
4. Why Does My Espresso Taste Sour?
5. Why Does My Espresso Taste Bitter?
6. How Long Do Espresso Machines Last?
7. How to Make Better Espresso at Home
8. How to Froth Milk for Espresso Drinks
9. How to Pull a Better Espresso Shot at Home
10. Espresso Machine Troubleshooting Guide

Internal linking:
- Maintenance pages link to ownership and beginner education pages.
- Taste troubleshooting pages link to grinder, pressure, and beginner pages.
- These pages support trust, not direct selling.
