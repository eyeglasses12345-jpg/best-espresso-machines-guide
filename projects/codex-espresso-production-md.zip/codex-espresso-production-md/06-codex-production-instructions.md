# Codex Production Instructions

Use this folder as the source of truth for production batches and page generation.

Do not rebuild the strategy system.
Do not rewrite the taxonomy unless instructed.
Do not invent a new site architecture.

Your job is production.

## Required Output

For each page, create one markdown file.

Each markdown file must include:
1. Metadata block
2. Snippet
3. HTML Description
4. HTML FAQ
5. HTML Schema
6. Internal link notes if needed

## File Naming Convention

Use slug names.

Example:

```text
best-espresso-machines-under-500.md
automatic-vs-semi-automatic-espresso-machine.md
how-to-clean-an-espresso-machine.md
```

## Folder Convention

Use:

```text
/pages/batch-01-money-pages/
/pages/batch-02-budget-buyer-fit/
/pages/batch-03-machine-drink-intent/
/pages/batch-04-comparison-decision/
/pages/batch-05-regret-prevention/
/pages/batch-06-maintenance-ownership/
```

## Production Rules

- Follow the batch order.
- Generate pages one batch at a time.
- Preserve page roles.
- Preserve internal linking logic.
- Do not create thin affiliate pages.
- Every page must answer the primary question immediately.
- Every page must include metadata.
- Every page must include FAQ.
- Every page must include schema.
- Every commercial page must include affiliate CTA placement.
- Every page must include relevant internal links.
- Do not include an H1 inside HTML Description.
- Use CMS-ready HTML sections.
- Use VA notes before tables.
- Do not use raw HTML tables unless explicitly requested.

## QA Before Completing a Page

Check:
- Does the page answer the core question in the first line?
- Is the reader’s decision easier after reading?
- Are the product roles clear?
- Are tradeoffs explained?
- Are internal links natural?
- Is the page extractable by AI?
- Does the FAQ match the page?
- Does the schema match the FAQ?
- Is the page CMS-ready?
