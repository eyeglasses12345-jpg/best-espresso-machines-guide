# Codex Production Handoff — Best Espresso Machines Guide

This folder contains the production assets Codex needs for the BestEspressoMachinesGuide.com affiliate authority site.

This is not the full strategy system.
This is the operational production package:

- taxonomy
- page batches
- page map
- production queue
- internal linking map
- page template
- affiliate asset handling
- QA checklist

Codex should use these files to generate CMS-ready page files in markdown/HTML-ready format.
