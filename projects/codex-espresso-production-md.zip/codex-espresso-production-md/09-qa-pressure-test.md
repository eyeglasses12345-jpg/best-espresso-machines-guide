# QA Pressure Test

Use this checklist after Codex generates each page.

## 7-Layer Page Test

### 1. Intent Match

Does the page answer the exact question the reader searched?

Pass/fail:
- Pass if the first screen clearly answers the query.
- Fail if the page opens with generic content.

### 2. Decision Completeness

Does the page give enough information to make a buying decision?

Check:
- buyer type
- budget
- skill level
- drink preference
- tradeoffs
- regret factors
- who should not buy

### 3. Decision Clarity

Is the recommendation easy to understand?

Check:
- clear best picks
- clear product roles
- no vague “it depends” without guidance
- strong comparison logic

### 4. Authority Signal

Does the page sound like it understands espresso machines and buyer mistakes?

Check:
- workflow
- grinder
- milk frothing
- cleaning
- pressure
- heat consistency
- durability
- learning curve

### 5. Regret Coverage

Does the page prevent common mistakes?

Check:
- cheap machine disappointment
- grinder confusion
- milk frothing limitations
- small kitchen constraints
- maintenance burden
- unrealistic expectations

### 6. AI Extractability

Can AI easily understand and summarize the answer?

Check:
- direct answer at top
- clear product roles
- structured sections
- FAQs
- schema
- consistent terminology

### 7. Click Trigger Strength

Does the page make affiliate clicks feel useful?

Check:
- CTA placement
- product role clarity
- confidence-building explanation
- no spammy sales language

## Final Judgment Labels

Use:
- publish_ready
- needs_light_revision
- needs_major_revision
- rebuild_required
